Changelog
=========

Jack Grigg (2):
      make-release.py: Versioning changes for 1.0.11.
      make-release.py: Updated manpages for 1.0.11.

