Changelog
=========

Jack Grigg (5):
      Fix pyflakes warnings in RPC tests
      Individualise performance-measurements.sh errors for debugging
      Fix incorrect failure in memory benchmark
      make-release.py: Versioning changes for 1.0.12.
      make-release.py: Updated manpages for 1.0.12.

Simon Liu (2):
      Update which lock to synchronize on when calling GetBestAnchor().
      Closes #2637. Make z_shieldcoinbase an experimental feature where it     can be enabled with: zcashd -experimentalfeatures -zshieldcoinbase.

